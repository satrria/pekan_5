<?php

namespace App\Http\Controllers;

use App\Pelajar;
use Illuminate\Http\Request;
use Psy\CodeCleaner\EmptyArrayDimFetchPass;

class StudentController extends Controller
{
    //

    public function index()
    {
        $pelajars = Pelajar::all();


        if (!empty($Pelajars)) {
            $response =
                [
                    'message' => 'semua data telah di upload',
                    'data' => $Pelajars,
                ];

            return response()->json(['posts' => $pelajars], 200, $response);
        } else {
            $response = [
                'message' => 'data tidak ada'
            ];

            return response()->json($response, 200);
        }

    }
    public function update(Request $request){

    }

    public function store(Request $request)
    {


        $pelajars = Pelajar::create($request->all());

        $response = [
            'message' => 'Student is created succesfully',
            'data' => $pelajars,
        ];

        return response()->json($response, 201);
    }

    //menghapus data
    public function destroy(Request $request, $id)
    {


        $book = Pelajar::find($id);
        $book->delete();
        return "data dengan id " . $id . " dihapus";
    }
}